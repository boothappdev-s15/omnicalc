module CalculationsHelper
end
